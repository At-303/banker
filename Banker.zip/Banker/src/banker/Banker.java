package banker;

import java.util.Scanner;

public class Banker {

    static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        char use;
        do {
            System.out.println("******Banker's Algorithm******");
            System.out.print("Enter 'y' to use, 'n' to exit: ");
            use = in.next().charAt(0);
            switch (use) {
                case 'y':
                    System.out.print("Enter the number of processes: ");
                    int n_P = in.nextInt();
                    System.out.print("Enter the number of resources: ");
                    int n_R = in.nextInt();
                    int[] available = available(n_R);
                    int[][] max = max(n_P, n_R);
                    int[][] allocation = allocation(n_P, n_R);
                    if (!isValid(allocation, max, available, n_P, n_R)) {
                        in.close();
                        return;
                    }
                    int[][] need = need(allocation, max, n_P, n_R);
                    printMatrices(allocation, need, max, available, n_P, n_R);
                    boolean deadlock = isDeadlock(allocation, max, need, available, n_P, n_R);
                    System.out.println("\nDeadlock detected: " + deadlock);
                    System.out.println("Do you want for Pn to requast Rn (y/n)");
                    char Q = in.next().charAt(0);
                    if (Q == 'n') {
                        break;
                    } else {
                        request(allocation, max, need, available, n_P, n_R);
                    }
                    break;
                case 'n':
                    System.out.println("Thank you for using this tool!");
                    System.out.println("Made by Atheer :)");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (use != 'n');
        in.close();
    }

    //  just reading from the user the available matrix
    static int[] available(int n_R) {
        int[] available = new int[n_R];
        System.out.println("\nEnter available resources (the total resources): ");
        for (int r = 0; r < n_R; r++) {
            System.out.print("R" + r + " ");
        }
        System.out.println();
        for (int i = 0; i < n_R; i++) {
            available[i] = in.nextInt();
        }
        return available;
    }

    //  just reading from the user the max matrix
    static int[][] max(int n_P, int n_R) {
        int[][] max = new int[n_P][n_R];
        System.out.println("Enter max matrix (each row represents a process):");
        for (int r = 0; r < n_R; r++) {
            System.out.print("  R" + r + " ");
        }
        System.out.println();
        for (int i = 0; i < n_P; i++) {
            System.out.print("P" + i + ": ");
            for (int j = 0; j < n_R; j++) {
                max[i][j] = in.nextInt();
            }
        }
        return max;
    }

    //  just reading from the user the allocation matrix
    static int[][] allocation(int n_P, int n_R) {
        int[][] allocation = new int[n_P][n_R];
        System.out.println("\nEnter allocation matrix :");
        for (int r = 0; r < n_R; r++) {
            System.out.print("  R" + r + " ");
        }
        System.out.println();
        for (int i = 0; i < n_P; i++) {
            System.out.print("P" + i + ": ");
            for (int j = 0; j < n_R; j++) {
                allocation[i][j] = in.nextInt();
            }
        }

        return allocation;
    }

    // calculation the need matrix 
    static int[][] need(int[][] allocation, int[][] max, int n_P, int n_R) {
        int[][] need = new int[n_P][n_R];
        for (int i = 0; i < n_P; i++) {
            for (int j = 0; j < n_R; j++) {
                need[i][j] = max[i][j] - allocation[i][j];
            }
        }
        return need;
    }

    // Helper method just to Simplifying the main
    static boolean isValid(int[][] allocation, int[][] max, int[] available, int n_P, int n_R) {
        if (!isValidAvailable(allocation, available, n_P, n_R)) {
            return false;
        }
        if (!isValidAllocation(allocation, max, n_P, n_R)) {
            return false;
        }
        return true;
    }

    // Check if total allocated resources are within available resources
    static boolean isValidAvailable(int[][] allocation, int[] available, int n_P, int n_R) {
        for (int i = 0; i < n_P; i++) {
            for (int j = 0; j < n_R; j++) {
                if (allocation[i][j] > available[j]) {
                    System.err.println("Invalid input: Allocation for P" + i + " on R" + j + " exceeds available resources.");
                    return false;
                }
            }
        }
        return true; // All processes' allocations are within limits
    }

    // Check if allocated resources for each process are within their max needs
    static boolean isValidAllocation(int[][] allocation, int[][] max, int n_P, int n_R) {
        for (int i = 0; i < n_P; i++) {
            for (int j = 0; j < n_R; j++) {
                if (allocation[i][j] > max[i][j]) {
                    System.err.println("Invalid allocation: Allocated resources exceed maximum needs for process P" + i + ", resource R" + j);
                    return false;
                }
            }
        }
        return true;
    }

    // to print all the Matrices for the ueser to see 
    static void printMatrices(int[][] allocation, int[][] need, int[][] max, int[] available, int n_P, int n_R) {
        System.out.println("****** here is your Matrices ******");
        System.out.println("\nAllocation Matrix:");
        printMatrix(allocation, n_P, n_R);
        System.out.println("\nMaximum Matrix:");
        printMatrix(max, n_P, n_R);
        System.out.println("\nNeed Matrix (Max - Allocation):");
        printMatrix(need, n_P, n_R);
        System.out.println("\nAvailable Resources:"); // i can not use the helper method cuse the available is 1D matrix 
        for (int r = 0; r < n_R; r++) {
            System.out.print("R" + r + " ");
        }
        System.out.println();
        for (int i = 0; i < n_R; i++) {
            System.out.print(available[i] + " ");
        }
        System.out.println("\n***********\n");
    }

    // Helper method to print a matrix to make coding less complexity heehe
    static void printMatrix(int[][] matrix, int rows, int cols) {
        for (int r = 0; r < cols; r++) {
            System.out.print("  R" + r + " ");
        }
        System.out.println();
        for (int i = 0; i < rows; i++) {
            System.out.print("P" + i + ": ");
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    //  deadlock detection 
    static boolean isDeadlock(int[][] allocation, int[][] max, int[][] need, int[] available, int n_P, int n_R) {
        boolean[] finished = new boolean[n_P]; // Tracks if a process is finished
        int[] work = available.clone(); // Copy of available resources
        int[] safeSequence = new int[n_P];
        int count = 0;
        while (count < n_P) {
            boolean foundProcess = false;
            for (int i = 0; i < n_P; i++) {
                if (!finished[i]) {
                    // Check if this process can finish
                    boolean canFinish = true;
                    for (int j = 0; j < n_R; j++) {
                        if (need[i][j] > work[j]) {
                            canFinish = false;
                            break;
                        }
                    }

                    // If the process can finish, mark it and update resources
                    if (canFinish) {
                        for (int j = 0; j < n_R; j++) {
                            work[j] += allocation[i][j];
                        }
                        safeSequence[count++] = i;
                        finished[i] = true;
                        foundProcess = true;
                    }
                }
            }
            // If no process can finish in this cycle, there's a deadlock
            if (!foundProcess) {
                System.out.println("Deadlock detected! No safe sequence exists.");
                return false;
            }
        }
        // Print the safe sequence
        System.out.print("Safe sequence: [");
        for (int i = 0; i < n_P; i++) {
            System.out.print("P" + safeSequence[i]);
            if (i < n_P - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
        return true;
    }

    static void request(int[][] allocation, int[][] max, int[][] need, int[] available, int n_P, int n_R) {
        System.out.println("\nProcess Request:");
        System.out.print("Enter the process number (0 to n-1): \n ");
        int P = in.nextInt();
        int[] request = new int[n_R];
        // i made this because i don't want to chang the OGs arrays
        int[][] new_allocation = allocation.clone();
        int[][] new_max = max.clone();
        int[][] new_need = need.clone();
        int[] new_available = available.clone();
        // read form the user
        System.out.println("Enter the request for each resource (separated by spaces): ");
        for (int i = 0; i < n_R; i++) {
            request[i] = in.nextInt();
        }
        // cheacking the 2 Condition 
        boolean validRequest = true;
        for (int i = 0; i < n_R; i++) {
            if (request[i] >= new_need[P][i] || request[i] >= new_available[i]) {
                validRequest = false;
                break;
            }
        }
        // cheacking for the last Condition 
        if (validRequest) {
            for (int i = 0; i < n_R; i++) {
                new_available[i] -= request[i];
                new_allocation[P][i] += request[i];
                new_need[P][i] -= request[i];
            }
            if (isDeadlock(new_allocation, new_max, new_need, new_available, n_P, n_R)) {
                System.out.println("Request granted. System is in a safe state.");

            } else {
                System.out.println("Request cannot be granted. System will enter an unsafe state.");
            }
        } else {
            System.out.println("Invalid request. Request exceeds need or available resources.");
        }
    }
}
